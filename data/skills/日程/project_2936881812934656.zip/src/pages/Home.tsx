/**
 * 首页 - 便签列表页
 * 数据存储在 IndexedDB，按用户隔离
 */

import { useState, useEffect, useCallback } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogCancel,
  AlertDialogAction,
} from '@/components/ui/alert-dialog';
import {
  Plus,
  Search,
  Pencil,
  Trash2,
  StickyNote,
  RotateCcw,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { getCurrentUserId, resetUserId } from '@/lib/userService';
import * as db from '@/lib/db';

// ============================================
// Zod 验证模式
// ============================================

const noteFormSchema = z.object({
  title: z.string().min(1, '标题不能为空').max(100, '标题最多100个字符'),
  content: z.string().max(2000, '内容最多2000个字符').optional().default(''),
});

type NoteFormValues = z.infer<typeof noteFormSchema>;

// ============================================
// 便签表单组件
// ============================================

interface NoteFormProps {
  defaultValues?: Partial<NoteFormValues>;
  onSubmit: (data: NoteFormValues) => void;
  onCancel: () => void;
  loading?: boolean;
}

function NoteForm({ defaultValues, onSubmit, onCancel, loading }: NoteFormProps) {
  const form = useForm<NoteFormValues>({
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    resolver: zodResolver(noteFormSchema) as any,
    defaultValues: {
      title: '',
      content: '',
      ...defaultValues,
    },
  });

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="title"
          render={({ field }) => (
            <FormItem>
              <FormLabel>标题</FormLabel>
              <FormControl>
                <Input placeholder="请输入标题" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="content"
          render={({ field }) => (
            <FormItem>
              <FormLabel>内容</FormLabel>
              <FormControl>
                <Textarea placeholder="请输入内容（可选）" rows={4} {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <DialogFooter className="gap-2">
          <Button type="button" variant="outline" onClick={onCancel}>
            取消
          </Button>
          <Button type="submit" disabled={loading}>
            {loading ? '保存中...' : '保存'}
          </Button>
        </DialogFooter>
      </form>
    </Form>
  );
}

// ============================================
// 格式化时间
// ============================================

function formatDate(iso: string): string {
  try {
    const d = new Date(iso);
    return new Intl.DateTimeFormat('zh-CN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    }).format(d);
  } catch {
    return iso;
  }
}

// ============================================
// 主页面组件
// ============================================

export default function Home() {
  const userId = getCurrentUserId();
  const [records, setRecords] = useState<db.Record[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  // Dialog states
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [editTarget, setEditTarget] = useState<db.Record | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<db.Record | null>(null);

  const loadRecords = useCallback(async () => {
    setLoading(true);
    try {
      const data = await db.getByUser(userId);
      setRecords(data);
    } catch (e) {
      console.error('Failed to load records:', e);
    } finally {
      setLoading(false);
    }
  }, [userId]);

  useEffect(() => {
    loadRecords();
  }, [loadRecords]);

  // 过滤记录
  const filteredRecords = records.filter((r) => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return r.title.toLowerCase().includes(q) || r.content.toLowerCase().includes(q);
  });

  // 新增
  const handleAdd = async (data: NoteFormValues) => {
    setSubmitting(true);
    await db.create(userId, { title: data.title, content: data.content || '' });
    setSubmitting(false);
    setShowAddDialog(false);
    loadRecords();
  };

  // 编辑
  const handleEdit = async (data: NoteFormValues) => {
    if (!editTarget) return;
    setSubmitting(true);
    await db.update(editTarget.id, userId, { title: data.title, content: data.content || '' });
    setSubmitting(false);
    setShowEditDialog(false);
    setEditTarget(null);
    loadRecords();
  };

  // 删除
  const handleDelete = async () => {
    if (!deleteTarget) return;
    await db.remove(deleteTarget.id, userId);
    setShowDeleteDialog(false);
    setDeleteTarget(null);
    loadRecords();
  };

  // 切换用户
  const handleSwitchUser = () => {
    if (!confirm('切换用户将清空本地用户ID，是否继续？')) return;
    resetUserId();
    window.location.reload();
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* 顶部栏 */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="mx-auto max-w-3xl px-4 py-4">
          <div className="flex items-center justify-between mb-3">
            <h1 className="text-xl font-bold text-gray-900 flex items-center gap-2">
              <StickyNote className="h-5 w-5 text-amber-500" />
              我的便签
            </h1>
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                variant="ghost"
                onClick={handleSwitchUser}
                title="切换用户"
                className="text-gray-400 hover:text-gray-600"
              >
                <RotateCcw className="h-4 w-4" />
              </Button>
              <Button onClick={() => setShowAddDialog(true)} size="sm">
                <Plus className="mr-1 h-4 w-4" />
                新增
              </Button>
            </div>
          </div>

          {/* 搜索框 */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="搜索标题或内容..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9"
            />
          </div>
        </div>
      </div>

      {/* 内容区 */}
      <div className="mx-auto max-w-3xl px-4 py-6">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-20 text-gray-400">
            <div className="h-8 w-8 border-4 border-gray-200 border-t-amber-500 rounded-full animate-spin mb-4" />
            <p className="text-sm">加载中...</p>
          </div>
        ) : filteredRecords.length === 0 ? (
          <Card className="flex flex-col items-center justify-center py-16 text-gray-400">
            <StickyNote className="mb-4 h-12 w-12 opacity-20" />
            <p className="text-base font-medium mb-1">
              {search ? '未找到匹配的便签' : '暂无便签'}
            </p>
            <p className="text-sm text-gray-400">
              {search ? '试试其他关键词' : '点击右上角「新增」创建第一条便签'}
            </p>
          </Card>
        ) : (
          <div className="space-y-3">
            {filteredRecords.map((record) => (
              <Card
                key={record.id}
                className={cn(
                  'group relative p-4 transition-all hover:shadow-sm',
                  'border border-gray-200 hover:border-gray-300'
                )}
              >
                <div className="pr-20">
                  <h3 className="font-semibold text-gray-900 mb-1 line-clamp-1">
                    {record.title}
                  </h3>
                  {record.content && (
                    <p className="text-sm text-gray-500 line-clamp-3 mb-2">
                      {record.content}
                    </p>
                  )}
                  <p className="text-xs text-gray-400">{formatDate(record.createdAt)}</p>
                </div>

                {/* 操作按钮 */}
                <div className="absolute right-3 top-1/2 -translate-y-1/2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => { setEditTarget(record); setShowEditDialog(true); }}
                    className="h-8 w-8 p-0 text-gray-400 hover:text-blue-500"
                    title="编辑"
                  >
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => { setDeleteTarget(record); setShowDeleteDialog(true); }}
                    className="h-8 w-8 p-0 text-gray-400 hover:text-red-500"
                    title="删除"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* 新增弹窗 */}
      <Dialog open={showAddDialog} onOpenChange={(v) => !v && setShowAddDialog(false)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>新增便签</DialogTitle>
            <DialogDescription>填写标题和内容</DialogDescription>
          </DialogHeader>
          <NoteForm
            onSubmit={handleAdd}
            onCancel={() => setShowAddDialog(false)}
            loading={submitting}
          />
        </DialogContent>
      </Dialog>

      {/* 编辑弹窗 */}
      <Dialog open={showEditDialog} onOpenChange={(v) => !v && (setShowEditDialog(false), setEditTarget(null))}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>编辑便签</DialogTitle>
            <DialogDescription>修改标题和内容</DialogDescription>
          </DialogHeader>
          {editTarget && (
            <NoteForm
              defaultValues={{
                title: editTarget.title,
                content: editTarget.content || '',
              }}
              onSubmit={handleEdit}
              onCancel={() => { setShowEditDialog(false); setEditTarget(null); }}
              loading={submitting}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* 删除确认弹窗 */}
      <AlertDialog
        open={showDeleteDialog}
        onOpenChange={(v) => !v && (setShowDeleteDialog(false), setDeleteTarget(null))}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>确认删除</AlertDialogTitle>
            <AlertDialogDescription>
              确定要删除便签「{deleteTarget?.title}」吗？此操作无法撤销。
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>取消</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-red-500 hover:bg-red-600"
            >
              删除
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
