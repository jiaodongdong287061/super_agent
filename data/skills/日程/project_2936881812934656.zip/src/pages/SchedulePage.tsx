/**
 * 日程管理页面
 * 支持增删改查，数据存储在 localStorage
 */

import { useState, useCallback } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogCancel,
  AlertDialogAction,
} from '@/components/ui/alert-dialog';
import {
  Plus,
  Calendar,
  Clock,
  Pencil,
  Trash2,
  Sparkles,
  CheckCircle2,
  XCircle,
} from 'lucide-react';
import {
  scheduleService,
  parseSmartInput,
  type Schedule,
  type ScheduleStatus,
} from '@/lib/scheduleService';
import { cn } from '@/lib/utils';

// ============================================
// Zod 验证模式
// ============================================

const scheduleFormSchema = z.object({
  title: z.string().min(1, '标题不能为空').max(100, '标题最多100个字符'),
  description: z.string().max(500, '描述最多500个字符').optional().default(''),
  time: z.string().min(1, '创建时间不能为空'),
  executeTime: z.string().min(1, '执行时间不能为空'),
});

type ScheduleFormValues = z.infer<typeof scheduleFormSchema>;

// ============================================
// 辅助函数
// ============================================

function formatScheduleTime(isoTime: string): string {
  try {
    const date = new Date(isoTime);
    const now = new Date();
    const todayStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    const tomorrowStr = `${tomorrow.getFullYear()}-${String(tomorrow.getMonth() + 1).padStart(2, '0')}-${String(tomorrow.getDate()).padStart(2, '0')}`;
    const dateStr = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
    const timeStr = `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;

    if (dateStr === todayStr) return `今天 ${timeStr}`;
    if (dateStr === tomorrowStr) return `明天 ${timeStr}`;
    const month = date.getMonth() + 1;
    const day = date.getDate();
    return `${month}/${day} ${timeStr}`;
  } catch {
    return isoTime;
  }
}

function isExpired(isoTime: string): boolean {
  try {
    return new Date(isoTime) < new Date();
  } catch {
    return false;
  }
}

// ============================================
// 日程表单组件
// ============================================

interface ScheduleFormProps {
  defaultValues?: Partial<ScheduleFormValues>;
  onSubmit: (data: ScheduleFormValues) => void;
  onCancel: () => void;
  loading?: boolean;
}

function ScheduleForm({ defaultValues, onSubmit, onCancel, loading }: ScheduleFormProps) {
  const form = useForm<ScheduleFormValues>({
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    resolver: zodResolver(scheduleFormSchema) as any,
    defaultValues: {
      title: '',
      description: '',
      time: '',
      executeTime: '',
      ...defaultValues,
    },
  });

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="title"
          render={({ field }) => (
            <FormItem>
              <FormLabel>标题</FormLabel>
              <FormControl>
                <Input placeholder="请输入日程标题" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>描述</FormLabel>
              <FormControl>
                <Textarea placeholder="请输入日程描述（可选）" rows={3} {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="time"
          render={({ field }) => (
            <FormItem>
              <FormLabel>创建时间</FormLabel>
              <FormControl>
                <Input type="datetime-local" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="executeTime"
          render={({ field }) => (
            <FormItem>
              <FormLabel>执行时间</FormLabel>
              <FormControl>
                <Input type="datetime-local" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <DialogFooter className="gap-2">
          <Button type="button" variant="outline" onClick={onCancel}>
            取消
          </Button>
          <Button type="submit" disabled={loading}>
            {loading ? '保存中...' : '保存'}
          </Button>
        </DialogFooter>
      </form>
    </Form>
  );
}

// ============================================
// 主页面组件
// ============================================

export function SchedulePage() {
  const [schedules, setSchedules] = useState<Schedule[]>(() => scheduleService.getPending());
  const [statusFilter, setStatusFilter] = useState<ScheduleStatus | 'all'>('pending');
  const [editTarget, setEditTarget] = useState<Schedule | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Schedule | null>(null);
  const [smartInput, setSmartInput] = useState('');
  const [smartFeedback, setSmartFeedback] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [pendingSmartAdd, setPendingSmartAdd] = useState<Partial<ScheduleFormValues> | null>(null);

  const refresh = useCallback(() => {
    if (statusFilter === 'all') {
      setSchedules(scheduleService.getAll());
    } else if (statusFilter === 'pending') {
      setSchedules(scheduleService.getPending());
    } else {
      setSchedules(scheduleService.getByStatus(statusFilter));
    }
  }, [statusFilter]);

  // 处理智能输入
  const handleSmartSubmit = () => {
    if (!smartInput.trim()) return;

    const result = parseSmartInput(smartInput);
    setSmartFeedback(null);

    if (result.action === 'delete') {
      if (result.targetId) {
        const targetId: string = result.targetId;
        const found = schedules.find(s => s.id === targetId || s.title.includes(targetId));
        if (found) {
          setDeleteTarget(found);
          setSmartInput('');
          return;
        } else {
          setSmartFeedback(`未找到日程 "${result.targetId}"`);
          return;
        }
      }
      setSmartFeedback('请指定要删除的日程，例如：删除 #日程ID');
      return;
    }

    if (result.action === 'edit') {
      if (result.targetId) {
        const targetId: string = result.targetId;
        const found = schedules.find(s => s.id === targetId || s.title.includes(targetId));
        if (found) {
          setEditTarget(found);
          setShowEditDialog(true);
          setSmartInput('');
          return;
        } else {
          setSmartFeedback(`未找到日程 "${result.targetId}"`);
          return;
        }
      }
      setSmartFeedback('请指定要编辑的日程，例如：编辑 #日程ID');
      return;
    }

    if (result.action === 'add' && result.schedule) {
      const schedule = result.schedule;
      if (schedule.time && schedule.title) {
        // 直接添加
        setLoading(true);
        scheduleService.create({
          title: schedule.title,
          description: schedule.description || '',
          time: schedule.time,
          executeTime: schedule.time,
        });
        setLoading(false);
        refresh();
        setSmartInput('');
        setSmartFeedback(`已添加日程：${schedule.title}`);
      } else {
        // 缺少时间或标题，弹出表单让用户补充
        setPendingSmartAdd({
          title: schedule.title || '',
          description: schedule.description || '',
          time: schedule.time || '',
          executeTime: schedule.time || '',
        });
        setShowAddDialog(true);
      }
      return;
    }

    setSmartFeedback('无法识别输入，请尝试：添加 明天14点 会议');
  };

  // 手动表单新增
  const handleAddSubmit = (data: ScheduleFormValues) => {
    setLoading(true);
    if (pendingSmartAdd) {
      scheduleService.create({
        title: data.title,
        description: data.description || '',
        time: new Date(data.time).toISOString(),
        executeTime: new Date(data.executeTime).toISOString(),
      });
      setPendingSmartAdd(null);
    } else {
      scheduleService.create({
        title: data.title,
        description: data.description || '',
        time: new Date(data.time).toISOString(),
        executeTime: new Date(data.executeTime).toISOString(),
      });
    }
    setLoading(false);
    setShowAddDialog(false);
    setSmartInput('');
    refresh();
  };

  // 编辑提交
  const handleEditSubmit = (data: ScheduleFormValues) => {
    if (!editTarget) return;
    setLoading(true);
    scheduleService.update(editTarget.id, {
      title: data.title,
      description: data.description || '',
      time: new Date(data.time).toISOString(),
      executeTime: new Date(data.executeTime).toISOString(),
    });
    setLoading(false);
    setShowEditDialog(false);
    setEditTarget(null);
    refresh();
  };

  // 删除确认
  const handleConfirmDelete = () => {
    if (!deleteTarget) return;
    scheduleService.delete(deleteTarget.id);
    setDeleteTarget(null);
    refresh();
  };

  // 标记完成
  const handleComplete = (id: string) => {
    scheduleService.complete(id);
    refresh();
  };

  // 标记取消
  const handleCancel = (id: string) => {
    scheduleService.cancel(id);
    refresh();
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="mx-auto max-w-2xl space-y-6">
        {/* 页面标题 */}
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-gray-900">日程管理</h1>
          <Button onClick={() => { setPendingSmartAdd(null); setShowAddDialog(true); }}>
            <Plus className="mr-1 h-4 w-4" />
            新增日程
          </Button>
        </div>

        {/* 智能输入区域 */}
        <Card className="p-4">
          <div className="mb-2 flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-amber-500" />
            <span className="text-sm font-medium text-gray-700">智能输入</span>
            <span className="text-xs text-gray-400">输入自然语言添加/编辑/删除日程</span>
          </div>
          <div className="flex gap-2">
            <Input
              placeholder='例如：明天14点开会 / 删除 #abc123 / 编辑 #abc123'
              value={smartInput}
              onChange={e => { setSmartInput(e.target.value); setSmartFeedback(null); }}
              onKeyDown={e => e.key === 'Enter' && handleSmartSubmit()}
              className="flex-1"
            />
            <Button onClick={handleSmartSubmit} disabled={!smartInput.trim()}>
              确定
            </Button>
          </div>
          {smartFeedback && (
            <p className={cn(
              'mt-2 text-sm',
              smartFeedback.startsWith('已') ? 'text-green-600' : 'text-amber-600'
            )}>
              {smartFeedback}
            </p>
          )}
          <div className="mt-2 flex flex-wrap gap-1 text-xs text-gray-400">
            <span className="rounded bg-gray-100 px-1.5 py-0.5">明天14点 会议</span>
            <span className="rounded bg-gray-100 px-1.5 py-0.5">5月20日 15:00 体检</span>
            <span className="rounded bg-gray-100 px-1.5 py-0.5">删除 #ID</span>
            <span className="rounded bg-gray-100 px-1.5 py-0.5">编辑 #ID</span>
          </div>
        </Card>

        {/* 日程列表 */}
        <div className="space-y-3">
          {schedules.length === 0 ? (
            <Card className="flex flex-col items-center justify-center py-12 text-gray-400">
              <Calendar className="mb-3 h-10 w-10 opacity-30" />
              <p className="text-sm">暂无待执行的日程</p>
              <p className="mt-1 text-xs">试试用智能输入添加：明天14点 开会</p>
            </Card>
          ) : (
            schedules.map(schedule => {
              const expired = isExpired(schedule.time);
              return (
                <Card
                  key={schedule.id}
                  className={cn(
                    'flex items-start gap-3 p-4 transition-all',
                    expired && 'border-amber-300 bg-amber-50'
                  )}
                >
                  {/* 状态图标 */}
                  <button
                    onClick={() => handleComplete(schedule.id)}
                    className={cn(
                      'mt-0.5 flex-shrink-0 rounded-full border-2 p-0.5 transition-colors',
                      expired
                        ? 'border-amber-400 text-amber-400 hover:border-amber-500 hover:text-amber-500'
                        : 'border-blue-400 text-blue-400 hover:border-blue-500 hover:text-blue-500'
                    )}
                    title="标记完成"
                  >
                    {expired ? (
                      <Clock className="h-4 w-4" />
                    ) : (
                      <CheckCircle2 className="h-4 w-4" />
                    )}
                  </button>

                  {/* 内容 */}
                  <div className="min-w-0 flex-1">
                    <div className={cn('font-medium', expired ? 'text-amber-800' : 'text-gray-900')}>
                      {schedule.title}
                    </div>
                    {schedule.description && (
                      <div className="mt-1 text-sm text-gray-500 line-clamp-2">
                        {schedule.description}
                      </div>
                    )}
                    <div className={cn(
                      'mt-2 flex items-center gap-1 text-xs',
                      expired ? 'text-amber-600' : 'text-gray-400'
                    )}>
                      <Clock className="h-3 w-3" />
                      {formatScheduleTime(schedule.time)}
                      {expired && <span className="ml-1 text-amber-500">（已过期）</span>}
                    </div>
                  </div>

                  {/* 操作按钮 */}
                  <div className="flex flex-shrink-0 gap-1">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => { setEditTarget(schedule); setShowEditDialog(true); }}
                      className="h-8 w-8 p-0 text-gray-400 hover:text-blue-500"
                      title="编辑"
                    >
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => setDeleteTarget(schedule)}
                      className="h-8 w-8 p-0 text-gray-400 hover:text-red-500"
                      title="删除"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </Card>
              );
            })
          )}
        </div>
      </div>

      {/* 新增日程弹窗 */}
      <Dialog open={showAddDialog} onOpenChange={v => { setShowAddDialog(v); if (!v) setPendingSmartAdd(null); }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{pendingSmartAdd ? '补充日程信息' : '新增日程'}</DialogTitle>
            <DialogDescription>
              填写日程的标题、描述和时间
            </DialogDescription>
          </DialogHeader>
          <ScheduleForm
            defaultValues={pendingSmartAdd ? {
              title: pendingSmartAdd.title || '',
              description: pendingSmartAdd.description || '',
              time: pendingSmartAdd.time
                ? pendingSmartAdd.time.slice(0, 16)
                : new Date().toISOString().slice(0, 16),
            } : undefined}
            onSubmit={handleAddSubmit}
            onCancel={() => { setShowAddDialog(false); setPendingSmartAdd(null); }}
            loading={loading}
          />
        </DialogContent>
      </Dialog>

      {/* 编辑日程弹窗 */}
      <Dialog open={showEditDialog} onOpenChange={v => { setShowEditDialog(v); if (!v) setEditTarget(null); }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>编辑日程</DialogTitle>
            <DialogDescription>
              修改日程的标题、描述和时间
            </DialogDescription>
          </DialogHeader>
          {editTarget && (
            <ScheduleForm
              defaultValues={{
                title: editTarget.title,
                description: editTarget.description || '',
                time: editTarget.time.slice(0, 16),
              }}
              onSubmit={handleEditSubmit}
              onCancel={() => { setShowEditDialog(false); setEditTarget(null); }}
              loading={loading}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* 删除确认弹窗 */}
      <AlertDialog open={!!deleteTarget} onOpenChange={v => { if (!v) setDeleteTarget(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>确认删除</AlertDialogTitle>
            <AlertDialogDescription>
              确定要删除日程「{deleteTarget?.title}」吗？此操作无法撤销。
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setDeleteTarget(null)}>
              取消
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleConfirmDelete}
              className="bg-red-500 hover:bg-red-600"
            >
              删除
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

export default SchedulePage;
