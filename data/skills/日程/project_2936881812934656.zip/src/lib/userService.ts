/**
 * 用户识别服务
 * 使用 localStorage 存储用户 ID，实现数据隔离
 */

const USER_ID_KEY = 'crud_app_user_id';

/** 获取当前用户 ID，若不存在则自动生成 */
export function getCurrentUserId(): string {
  let userId = localStorage.getItem(USER_ID_KEY);
  if (!userId) {
    userId = crypto.randomUUID();
    localStorage.setItem(USER_ID_KEY, userId);
  }
  return userId;
}

/** 重置用户 ID（切换用户/清除数据） */
export function resetUserId(): string {
  const newId = crypto.randomUUID();
  localStorage.setItem(USER_ID_KEY, newId);
  return newId;
}
