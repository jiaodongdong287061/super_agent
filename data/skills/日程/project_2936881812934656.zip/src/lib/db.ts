/**
 * IndexedDB 数据存储服务
 * 支持用户隔离的 CRUD 操作
 */

const DB_NAME = 'crud_indexeddb';
const DB_VERSION = 1;
const STORE_NAME = 'records';

/** 记录数据类型 */
export interface Record {
  id: string;
  userId: string;
  title: string;
  content: string;
  createdAt: string;
  updatedAt: string;
}

export type RecordInput = Pick<Record, 'title' | 'content'>;

let dbInstance: IDBDatabase | null = null;

/** 打开数据库连接 */
function openDB(): Promise<IDBDatabase> {
  if (dbInstance) return Promise.resolve(dbInstance);

  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const database = (event.target as IDBOpenDBRequest).result;
      if (!database.objectStoreNames.contains(STORE_NAME)) {
        const store = database.createObjectStore(STORE_NAME, { keyPath: 'id' });
        store.createIndex('userId', 'userId', { unique: false });
        store.createIndex('createdAt', 'createdAt', { unique: false });
      }
    };

    request.onsuccess = (event) => {
      dbInstance = (event.target as IDBOpenDBRequest).result;
      resolve(dbInstance);
    };

    request.onerror = (event) => {
      reject((event.target as IDBOpenDBRequest).error);
    };
  });
}

/**
 * 创建记录（属于指定用户）
 */
export function create(userId: string, data: RecordInput): Promise<Record> {
  const record: Record = {
    id: crypto.randomUUID(),
    userId,
    title: data.title,
    content: data.content,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  return openDB().then((db) => {
    return new Promise<Record>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const request = store.add(record);

      request.onsuccess = () => resolve(record);
      request.onerror = () => reject(request.error);
    });
  });
}

/**
 * 读取用户的所有记录（按创建时间倒序）
 */
export function getByUser(userId: string): Promise<Record[]> {
  return openDB().then((db) => {
    return new Promise<Record[]>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const index = store.index('userId');
      const request = index.getAll(userId);

      request.onsuccess = () => {
        const results = (request.result as Record[]).sort(
          (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        );
        resolve(results);
      };
      request.onerror = () => reject(request.error);
    });
  });
}

/**
 * 更新记录
 */
export function update(id: string, userId: string, data: Partial<RecordInput>): Promise<Record | null> {
  return openDB().then((db) => {
    return new Promise<Record | null>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const getReq = store.get(id);

      getReq.onsuccess = () => {
        const existing = getReq.result as Record | undefined;
        if (!existing || existing.userId !== userId) {
          resolve(null);
          return;
        }

        const updated: Record = {
          ...existing,
          title: data.title ?? existing.title,
          content: data.content ?? existing.content,
          updatedAt: new Date().toISOString(),
        };

        const putReq = store.put(updated);
        putReq.onsuccess = () => resolve(updated);
        putReq.onerror = () => reject(putReq.error);
      };
      getReq.onerror = () => reject(getReq.error);
    });
  });
}

/**
 * 删除记录
 */
export function remove(id: string, userId: string): Promise<boolean> {
  return openDB().then((db) => {
    return new Promise<boolean>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const getReq = store.get(id);

      getReq.onsuccess = () => {
        const existing = getReq.result as Record | undefined;
        if (!existing || existing.userId !== userId) {
          resolve(false);
          return;
        }

        const delReq = store.delete(id);
        delReq.onsuccess = () => resolve(true);
        delReq.onerror = () => reject(delReq.error);
      };
      getReq.onerror = () => reject(getReq.error);
    });
  });
}
