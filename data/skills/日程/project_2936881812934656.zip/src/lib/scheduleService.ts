// ============================================
// 日程数据模型
// ============================================

export type ScheduleStatus = 'pending' | 'cancelled' | 'completed';

export interface Schedule {
  id: string;
  title: string;
  description: string;
  time: string; // ISO 8601 格式，创建时间
  executeTime: string; // ISO 8601 格式，执行/会议时间
  status: ScheduleStatus;
  createdAt: string;
}

const STORAGE_KEY = 'schedules';

// ============================================
// localStorage CRUD 操作
// ============================================

function getAll(): Schedule[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveAll(items: Schedule[]): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
}

export const scheduleService = {
  /** 获取所有未执行的日程（待办） */
  getPending: (): Schedule[] => {
    return getAll()
      .filter(s => s.status === 'pending')
      .sort((a, b) => new Date(a.executeTime).getTime() - new Date(b.executeTime).getTime());
  },

  /** 根据状态筛选 */
  getByStatus: (status: ScheduleStatus): Schedule[] => {
    return getAll()
      .filter(s => s.status === status)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  },

  /** 获取所有日程 */
  getAll,

  /** 根据 ID 获取单个日程 */
  getById: (id: string): Schedule | undefined => {
    return getAll().find(s => s.id === id);
  },

  /** 新增日程 */
  create: (data: Omit<Schedule, 'id' | 'status' | 'createdAt'>): Schedule => {
    const item: Schedule = {
      ...data,
      id: crypto.randomUUID(),
      status: 'pending',
      createdAt: new Date().toISOString(),
    };
    saveAll([item, ...getAll()]);
    return item;
  },

  /** 更新日程 */
  update: (id: string, data: Partial<Omit<Schedule, 'id' | 'status' | 'createdAt'>>): Schedule | null => {
    const items = getAll();
    const index = items.findIndex(s => s.id === id);
    if (index === -1) return null;
    items[index] = { ...items[index], ...data };
    saveAll(items);
    return items[index];
  },

  /** 删除日程 */
  delete: (id: string): boolean => {
    const items = getAll();
    const next = items.filter(s => s.id !== id);
    if (next.length === items.length) return false;
    saveAll(next);
    return true;
  },

  /** 标记日程为已完成 */
  complete: (id: string): Schedule | null => {
    const items = getAll();
    const index = items.findIndex(s => s.id === id);
    if (index === -1) return null;
    items[index] = { ...items[index], status: 'completed' };
    saveAll(items);
    return items[index];
  },

  /** 标记日程为已取消 */
  cancel: (id: string): Schedule | null => {
    const items = getAll();
    const index = items.findIndex(s => s.id === id);
    if (index === -1) return null;
    items[index] = { ...items[index], status: 'cancelled' };
    saveAll(items);
    return items[index];
  },
};

// ============================================
// 智能输入解析
// ============================================

export interface SmartParseResult {
  action: 'add' | 'edit' | 'delete' | 'unknown';
  schedule?: Partial<Omit<Schedule, 'id' | 'status' | 'createdAt'>>;
  targetId?: string;
}

/** 从用户输入中解析出日程意图 */
export function parseSmartInput(input: string): SmartParseResult {
  const text = input.trim().toLowerCase();

  // 删除意图
  if (
    text.startsWith('删除') ||
    text.startsWith('删') ||
    text.startsWith('del') ||
    /^(删|删除|del|remove)\s*#?(\S+)/.test(text)
  ) {
    const idMatch = input.match(/#(\S+)/) || input.match(/(?:删除|删|del|remove)\s*(\S+)/);
    if (idMatch) {
      return { action: 'delete', targetId: idMatch[1] };
    }
    return { action: 'delete' };
  }

  // 编辑意图
  if (
    text.startsWith('编辑') ||
    text.startsWith('改') ||
    text.startsWith('修改') ||
    text.startsWith('edit') ||
    text.startsWith('update')
  ) {
    const idMatch = input.match(/#(\S+)/);
    if (idMatch) {
      return { action: 'edit', targetId: idMatch[1] };
    }
    return { action: 'edit' };
  }

  // 新增意图：检测时间模式
  let schedule: Partial<Omit<Schedule, 'id' | 'status' | 'createdAt'>> = {};
  let parsedTime: Date | null = null;
  let title = input;

  // 模式1：今天/明天/后天 + 内容
  const todayTomorrow = text.match(/^(今天|明天|后天|大后天)(.+)/);
  if (todayTomorrow) {
    const [dayWord, rest] = todayTomorrow;
    const base = new Date();
    const offset = dayWord === '今天' ? 0 : dayWord === '明天' ? 1 : dayWord === '后天' ? 2 : 3;
    base.setDate(base.getDate() + offset);

    const timeMatch = rest.match(/(\d{1,2})[点时:](\d{0,2})/);
    if (timeMatch) {
      base.setHours(parseInt(timeMatch[1]), parseInt(timeMatch[2] || '0'), 0, 0);
      title = rest.replace(/[上下下午凌晨中午夜里\d:：.点时分秒]+/g, '').trim();
    } else {
      base.setHours(9, 0, 0, 0);
      title = rest;
    }
    parsedTime = base;
  }

  // 模式2：MM/DD 或 MM月DD日
  const monthDay = input.match(/(\d{1,2})[月/](\d{1,2})(?:日|号)?(?:\s*)([早上下午晚上凌晨中午夜里\d:：.]+[点时分]?)?/);
  if (monthDay && !parsedTime) {
    const month = parseInt(monthDay[1]);
    const day = parseInt(monthDay[2]);
    const timeStr = monthDay[3] || '';
    parsedTime = new Date(new Date().getFullYear(), month - 1, day);
    if (timeStr) {
      const t = timeStr.match(/(\d{1,2})[点时:]?(\d{0,2})/);
      if (t) parsedTime.setHours(parseInt(t[1]), parseInt(t[2] || '0'), 0, 0);
    } else {
      parsedTime.setHours(9, 0, 0, 0);
    }
    title = input.replace(/[\d日月号/\s:：.点时分秒]+/g, ' ').trim();
  }

  // 模式3：YYYY-MM-DD
  const ymd = input.match(/(\d{4})[-/](\d{1,2})[-/](\d{1,2})(?:\s*)([早上下午晚上凌晨中午夜里\d:：.]+[点时分]?)?/);
  if (ymd && !parsedTime) {
    const year = parseInt(ymd[1]);
    const month = parseInt(ymd[2]) - 1;
    const day = parseInt(ymd[3]);
    const timeStr = ymd[4] || '';
    parsedTime = new Date(year, month, day);
    if (timeStr) {
      const t = timeStr.match(/(\d{1,2})[点时:]?(\d{0,2})/);
      if (t) parsedTime.setHours(parseInt(t[1]), parseInt(t[2] || '0'), 0, 0);
    } else {
      parsedTime.setHours(9, 0, 0, 0);
    }
    title = input.replace(/[\d-/：:.\s点时分秒]+/g, ' ').trim();
  }

  // 模式4：下午/早上 + 时间
  const ampm = input.match(/([早上下午晚上凌晨中午夜里]+)(\d{1,2})[点时分]?(\d{0,2})?/);
  if (ampm && !parsedTime) {
    const prefix = ampm[1];
    const hour = parseInt(ampm[2]);
    const minute = parseInt(ampm[3] || '0');
    parsedTime = new Date();
    parsedTime.setHours(hour, minute, 0, 0);
    if (prefix.includes('下午') || prefix.includes('晚上')) {
      if (hour < 12) parsedTime.setHours(hour + 12);
    } else if (prefix.includes('凌晨') || prefix.includes('夜里')) {
      if (hour >= 12) parsedTime.setDate(parsedTime.getDate() + 1);
    }
    title = input.replace(/[早上下午晚上凌晨中午夜里\d:：.点时分秒]+/g, ' ').trim();
  }

  // 纯时间判断：如果输入整体就是个时间，也算
  const justTime = input.match(/^(\d{1,2}):(\d{2})$/);
  if (justTime && !parsedTime) {
    parsedTime = new Date();
    parsedTime.setHours(parseInt(justTime[1]), parseInt(justTime[2]), 0, 0);
    title = input;
  }

  if (parsedTime) {
    schedule.time = parsedTime.toISOString();
  }

  // 清理标题
  title = title
    .replace(/^[,，、\s]+/, '')
    .replace(/[,，、\s]+$/, '')
    .trim();

  if (title.length > 0) {
    schedule.title = title;
  }

  // 判断是否为有效新增
  const hasTime = !!schedule.time;
  const hasTitle = !!schedule.title;

  if (hasTime || hasTitle) {
    schedule.description = schedule.description || '';
    return { action: 'add', schedule: hasTitle ? schedule : { ...schedule, title: '新建日程' } };
  }

  return { action: 'unknown' };
}
